-- =========================================================
-- Auto-generated extension provisioning INSERTs
-- Source: triverity.xlsx (Employees Name / Alias / Ext.)
-- Tables populated: ps_aors, ps_auths, ps_endpoints, voicemail
-- NOTE: ps_auths.password below uses placeholder '9999'.
--       Recommend running a scoped random-password UPDATE
--       afterward (WHERE id IN (...)) rather than blanket.
-- NOTE: 'Office Toll Free' row's alias cell was a wrapped
--       note ('Kim and Linda take these calls for Toll
--       Free'), not a person's alias -- inserted as-is per
--       instructions; flag if that's not what you want.
-- =========================================================

-- ps_auths
INSERT INTO public.ps_auths (id, auth_type, nonce_lifetime, md5_cred, "password", realm, username, refresh_token, oauth_clientid, oauth_secret)
VALUES
('1050', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1050', NULL, NULL, NULL),
('1030', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1030', NULL, NULL, NULL),
('6223', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6223', NULL, NULL, NULL),
('1010', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1010', NULL, NULL, NULL),
('6195', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6195', NULL, NULL, NULL),
('3010', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3010', NULL, NULL, NULL),
('1008', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1008', NULL, NULL, NULL),
('1304', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1304', NULL, NULL, NULL),
('1020', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1020', NULL, NULL, NULL),
('1040', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1040', NULL, NULL, NULL),
('9521', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9521', NULL, NULL, NULL),
('4455', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '4455', NULL, NULL, NULL),
('6983', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6983', NULL, NULL, NULL),
('3008', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3008', NULL, NULL, NULL),
('1056', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1056', NULL, NULL, NULL),
('1441', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1441', NULL, NULL, NULL),
('6982', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6982', NULL, NULL, NULL),
('1009', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1009', NULL, NULL, NULL),
('1014', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1014', NULL, NULL, NULL),
('1016', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1016', NULL, NULL, NULL),
('1331', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1331', NULL, NULL, NULL),
('1012', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1012', NULL, NULL, NULL),
('9523', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9523', NULL, NULL, NULL),
('1054', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1054', NULL, NULL, NULL),
('3011', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3011', NULL, NULL, NULL),
('6224', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6224', NULL, NULL, NULL),
('2233', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2233', NULL, NULL, NULL),
('9522', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9522', NULL, NULL, NULL),
('6214', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6214', NULL, NULL, NULL),
('3009', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3009', NULL, NULL, NULL),
('1022', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1022', NULL, NULL, NULL),
('2796', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2796', NULL, NULL, NULL),
('3013', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3013', NULL, NULL, NULL),
('6203', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6203', NULL, NULL, NULL),
('1013', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1013', NULL, NULL, NULL),
('1007', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1007', NULL, NULL, NULL),
('1105', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1105', NULL, NULL, NULL),
('6928', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6928', NULL, NULL, NULL),
('2955', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2955', NULL, NULL, NULL),
('3019', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '3019', NULL, NULL, NULL),
('1059', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1059', NULL, NULL, NULL),
('6199', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6199', NULL, NULL, NULL),
('1102', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1102', NULL, NULL, NULL),
('1301', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1301', NULL, NULL, NULL),
('1306', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1306', NULL, NULL, NULL),
('1084', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1084', NULL, NULL, NULL),
('2952', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2952', NULL, NULL, NULL),
('2415', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2415', NULL, NULL, NULL),
('0302', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '0302', NULL, NULL, NULL),
('6999', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6999', NULL, NULL, NULL),
('6130', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6130', NULL, NULL, NULL),
('6290', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6290', NULL, NULL, NULL),
('8034', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '8034', NULL, NULL, NULL),
('6216', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6216', NULL, NULL, NULL),
('2940', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2940', NULL, NULL, NULL),
('9976', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9976', NULL, NULL, NULL),
('6267', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6267', NULL, NULL, NULL),
('6165', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6165', NULL, NULL, NULL),
('6139', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6139', NULL, NULL, NULL),
('8242', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '8242', NULL, NULL, NULL),
('6111', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6111', NULL, NULL, NULL),
('8240', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '8240', NULL, NULL, NULL),
('6157', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6157', NULL, NULL, NULL),
('8210', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '8210', NULL, NULL, NULL),
('6219', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6219', NULL, NULL, NULL),
('6291', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6291', NULL, NULL, NULL),
('8045', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '8045', NULL, NULL, NULL),
('5409', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '5409', NULL, NULL, NULL),
('6225', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6225', NULL, NULL, NULL),
('6966', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '6966', NULL, NULL, NULL),
('2031', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '2031', NULL, NULL, NULL),
('9580', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9580', NULL, NULL, NULL),
('1887', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1887', NULL, NULL, NULL),
('9865', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '9865', NULL, NULL, NULL),
('1798', 'userpass'::public."pjsip_auth_type_values_v2", NULL, NULL, '9999', NULL, '1798', NULL, NULL, NULL);

-- Optional: randomize passwords for ONLY the newly added extensions
-- (scoped, unlike the blanket UPDATE in the original script)
UPDATE public.ps_auths
SET "password" = (
    SELECT array_to_string(
        array(
            SELECT substr('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', (floor(random() * 62) + 1)::int, 1)
            FROM generate_series(1, 12)
        ), ''
    )
)
WHERE id IN ('1050','1030','6223','1010','6195','3010','1008','1304','1020','1040','9521','4455','6983','3008','1056','1441','6982','1009','1014','1016','1331','1012','9523','1054','3011','6224','2233','9522','6214','3009','1022','2796','3013','6203','1013','1007','1105','6928','2955','3019','1059','6199','1102','1301','1306','1084','2952','2415','0302','6999','6130','6290','8034','6216','2940','9976','6267','6165','6139','8242','6111','8240','6157','8210','6219','6291','8045','5409','6225','6966','2031','9580','1887','9865','1798');
